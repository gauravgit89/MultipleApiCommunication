﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDAPApi.Controllers.Models
{
    public class RDAPEntity
    {
        public string SourceAddress { get; set; }
        public string IPVersion { get; set; }
        public string NetworkInterfaceName { get; set; }
        public ErrorEntity Error { get; set; }
    }
}
