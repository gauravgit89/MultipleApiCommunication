﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RDAPApi.Controllers.Models;

namespace RDAPApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RDAPApiController : ControllerBase
    {
        [HttpGet]
        [Route("getrdapapidetails")]
        public IActionResult GetIpDetails([FromQuery]string ip)
        {
            RDAPEntity entity = new RDAPEntity();

            entity.SourceAddress = "rdap source address";
            entity.NetworkInterfaceName = "network rdap interface";
            entity.Error = null;

            return Ok(entity);
        }
    }
}