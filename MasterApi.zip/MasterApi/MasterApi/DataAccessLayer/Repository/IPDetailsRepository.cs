﻿using Domain.Entities;
using Domain.Entities.Models;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repository
{
    public class IPDetailsRepository : GenericRepository<CombinedIPEntity>, IIPDetailsRepository
    {
        public IPDetailsRepository(ApplicationDBContext context) : base(context)
        {
        }

        public async Task<CombinedIPEntity> GetIPDetails(string ipAddress)
        {
            CombinedIPEntity combinedIpDetails = new CombinedIPEntity();
            try
            {
                List<string> apiUrls = PrepUrls(ipAddress);

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    List<Task<CombinedIPEntity>> tasks = new List<Task<CombinedIPEntity>>();

                    foreach (var apiUrl in apiUrls)
                    {
                        tasks.Add(GetModel(apiUrl, client));
                    }

                    var responses = await Task.WhenAll(tasks);

                    foreach (var response in responses)
                    {
                        combinedIpDetails.IP = combinedIpDetails.IP == null ? ipAddress : combinedIpDetails.IP;
                        combinedIpDetails.DNSName = combinedIpDetails.DNSName == null ? response.DNSName : combinedIpDetails.DNSName;
                        combinedIpDetails.GoLangSourceAddress = combinedIpDetails.GoLangSourceAddress == null ? response.GoLangSourceAddress : combinedIpDetails.GoLangSourceAddress;
                        combinedIpDetails.IPVersion = combinedIpDetails.IPVersion == null ? response.IPVersion : combinedIpDetails.IPVersion;
                        combinedIpDetails.NetworkInterfaceName = combinedIpDetails.NetworkInterfaceName == null ? response.NetworkInterfaceName : combinedIpDetails.NetworkInterfaceName;
                        combinedIpDetails.Source = combinedIpDetails.Source == null ? response.Source: combinedIpDetails.Source;
                        combinedIpDetails.TimeStamp = DateTime.Now;
                        combinedIpDetails.RDAPSourceAddress = combinedIpDetails.RDAPSourceAddress == null ? response.RDAPSourceAddress : combinedIpDetails.RDAPSourceAddress;

                        if (response.Errors != null)
                        {
                            if (response.Errors.Count > 0)
                            {
                                combinedIpDetails.Errors.AddRange(response.Errors);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }

            return combinedIpDetails;
        }

        public List<string> PrepUrls(string ipAddress)
        {
            //This can come from a json or config file
            List<string> apiUrls = new List<string>();
        
            apiUrls.Add("https://localhost:44366/api/GoLangApi/getgolangipdetails?ip=" + ipAddress);
            apiUrls.Add("https://localhost:44300/api/RDAPApi/getrdapapidetails?ip=" + ipAddress);
            
            return apiUrls;
        }

        public async Task<CombinedIPEntity> GetModel(string url, HttpClient client)
        {
            CombinedIPEntity ipEntity = new CombinedIPEntity();
            try
            {   
                //assuming all target apis may return different properties for an ip, populating relevant properties from target
                using (var response = await client.GetAsync(url))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        if (url.Contains("GoLang"))
                        {
                            GoLangEntity goLangEntity = await response.Content.ReadAsAsync<GoLangEntity>();
                            ipEntity.Source = "GoLang";
                            ipEntity.DNSName = goLangEntity.DNSName;
                            ipEntity.GoLangSourceAddress = goLangEntity.SourceAddress;
                            if (goLangEntity.Error != null)
                            {
                                ipEntity.Errors.Add(goLangEntity.Error);
                            }

                        }

                        if (url.Contains("RDAP"))
                        {
                            RDAPEntity rdapEntity = await response.Content.ReadAsAsync<RDAPEntity>();
                            ipEntity.Source = "RDAP";
                            ipEntity.IPVersion = rdapEntity.IPVersion;
                            ipEntity.NetworkInterfaceName = rdapEntity.NetworkInterfaceName;
                            ipEntity.RDAPSourceAddress = rdapEntity.SourceAddress;
                            if (rdapEntity.Error != null)
                            {
                                ipEntity.Errors.Add(rdapEntity.Error);
                            }
                        }

                        return ipEntity;
                    }
                    else
                    {
                        ipEntity.Source = url;
                        ipEntity.Errors.Add(new Domain.Entities.ErrorEntity() { ErrorCode = "5678", Source = url, Message = url + " did not respond with a success status code" });
                    }
                }
            }
            catch(Exception ex)
            {
                if(ex.Message.Contains("No connection could be made because the target machine actively refused it."))
                {
                    ipEntity.Source = url;
                    ipEntity.Errors.Add(new Domain.Entities.ErrorEntity() {ErrorCode="1234", Source = url, Message = url + " not responding" });
                }
            }
            return ipEntity;
        }
    }
}
