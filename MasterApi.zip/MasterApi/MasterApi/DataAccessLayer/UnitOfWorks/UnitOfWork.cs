﻿using DataAccessLayer.Repository;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.UnitOfWorks
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDBContext _context;

        public UnitOfWork(ApplicationDBContext context)
        {
            _context = context;
            IPDetailsRepository = new IPDetailsRepository(_context);
        }

        public IIPDetailsRepository IPDetailsRepository { get; set; }

        public int Save()
        {
             return _context.SaveChanges();
        }
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
