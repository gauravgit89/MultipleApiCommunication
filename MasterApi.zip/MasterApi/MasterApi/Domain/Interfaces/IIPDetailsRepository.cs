﻿using Domain.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IIPDetailsRepository : IGenericRepository<CombinedIPEntity>
    {
        Task<CombinedIPEntity> GetIPDetails(string ipAddress);
    }
}
