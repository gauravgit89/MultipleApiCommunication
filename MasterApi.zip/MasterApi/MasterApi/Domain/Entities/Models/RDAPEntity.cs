﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities.Models
{
    public class RDAPEntity
    {
        public string SourceAddress { get; set; }
        public string IPVersion { get; set; }
        public string NetworkInterfaceName { get; set; }
        public ErrorEntity Error { get; set; }
    }
}
