﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities.Models
{
    public class GoLangEntity
    {
        public string SourceAddress { get; set; }
        public string DNSName { get; set; }
        public ErrorEntity Error { get; set; }
    }
}
