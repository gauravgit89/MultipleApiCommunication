﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities.Models
{
    [Serializable]
    public class CombinedIPEntity
    {
        public string IP { get; set; }
        public string DNSName { get; set; }
        public string IPVersion { get; set; }
        public string NetworkInterfaceName { get; set; }
        public DateTime TimeStamp { get; set; }
        public string Source { get; set; }
        public string GoLangSourceAddress { get; set; }
        public string RDAPSourceAddress { get; set; }
        
        public List<ErrorEntity> Errors = new List<ErrorEntity>();
        public string ErrorText { get; set; }
    }
}
