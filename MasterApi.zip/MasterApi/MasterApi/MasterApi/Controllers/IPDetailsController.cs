﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Domain.Entities.Models;
using Domain.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MasterApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IPDetailsController : ControllerBase
    {

        private readonly IUnitOfWork _unitOfWork;

        public IPDetailsController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        [Route("getipdetails")]
        public async Task<IActionResult> GetIpDetails()
        {
            CombinedIPEntity ipEntity = new CombinedIPEntity();
            try
            {
                string hostName = Dns.GetHostName();
                string ip = Dns.GetHostEntry(hostName).AddressList[0].ToString();
                StringBuilder errorText = new StringBuilder();

                ipEntity = await _unitOfWork.IPDetailsRepository.GetIPDetails(ip);

                foreach (var error in ipEntity.Errors)
                {
                    errorText.Append("Error code: " + error.ErrorCode).Append(" --- Error Url : " + error.Source).Append(" --- Error Message : " + error.Message).AppendLine();
                }

                if (ipEntity.Errors.Count > 0)
                {
                    ipEntity.ErrorText = errorText.ToString();
                    return BadRequest(ipEntity);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

            return Ok(ipEntity);
        }
    }
}
