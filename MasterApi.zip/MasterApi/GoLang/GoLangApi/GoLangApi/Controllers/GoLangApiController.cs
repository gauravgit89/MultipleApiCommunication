﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GoLangApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GoLangApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GoLangApiController : ControllerBase
    {
        [HttpGet]
        [Route("getgolangipdetails")]
        public IActionResult GetIpDetails([FromQuery]string ip)
        {
            GoLangEntity entity = new GoLangEntity();

            entity.DNSName = "golang dns";
            entity.SourceAddress = "golang source address";
            entity.Error = null;

            return Ok(entity);
        }
    }
}