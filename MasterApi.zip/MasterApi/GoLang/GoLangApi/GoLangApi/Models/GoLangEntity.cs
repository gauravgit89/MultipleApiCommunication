﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoLangApi.Models
{
    public class GoLangEntity
    {
        public string SourceAddress { get; set; }
        public string DNSName { get; set; }
        public ErrorEntity Error { get; set; }
    }
}
